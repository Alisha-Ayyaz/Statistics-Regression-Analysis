import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder

# Load the dataset
file_path = 'healthcare_dataset.csv'  # Ensure the correct path if needed
data = pd.read_csv(file_path)

# Display basic information about the dataset
print("Dataset Head:")
print(data.head())
print("\nDataset Info:")
print(data.info())
print("\nDescriptive Statistics:")
print(data.describe())

# Handle missing values by dropping rows with NA values
print("\nMissing Values Before Handling:")
print(data.isnull().sum())
data.dropna(inplace=True)
print("\nMissing Values After Handling:")
print(data.isnull().sum())

# Convert categorical features to numeric using LabelEncoder
for column in data.columns:
    if data[column].dtype == 'object':
        encoder = LabelEncoder()
        data[column] = encoder.fit_transform(data[column])

# Descriptive statistics
print("\nDescriptive Statistics After Encoding:")
print(data.describe())

# Part 4: Correlation matrix and heatmap
correlation_matrix = data.corr()
print("\nCorrelation Matrix:")
print(correlation_matrix)

plt.figure(figsize=(10, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title("Correlation Heatmap")
plt.show()

# Part 5: Histograms and P-P plots for checking normality
for column in data.select_dtypes(include=np.number).columns:
    plt.figure(figsize=(12, 5))

    # Histogram
    plt.subplot(1, 2, 1)
    sns.histplot(data[column], kde=True)
    plt.title(f"Histogram of {column}")

    # P-P Plot
    plt.subplot(1, 2, 2)
    sm.qqplot(data[column], line='45', fit=True)
    plt.title(f"P-P Plot of {column}")

    plt.tight_layout()
    plt.show()

# Part 6: Perform Regression Analysis
# Assuming the last column is the dependent variable
dependent_variable = data.columns[-1]
independent_variables = data.columns[:-1]

X = data[independent_variables]
y = data[dependent_variable]

# Perform regression analysis using Statsmodels
X = sm.add_constant(X)  # Add constant for intercept
model = sm.OLS(y, X).fit()

print("\n--- Regression Analysis Summary ---")
print(model.summary())

# Linear Regression Model using sklearn
X = X.drop('const', axis=1)  # Remove constant for sklearn
reg_model = LinearRegression()
reg_model.fit(X, y)

# Model Evaluation
predictions = reg_model.predict(X)

mse = mean_squared_error(y, predictions)
r2 = r2_score(y, predictions)

print("\n--- Model Evaluation ---")
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"R-squared (R2): {r2:.4f}")

# Part 7: Plotting actual vs predicted values
plt.figure(figsize=(10, 6))
plt.scatter(y, predictions, alpha=0.7, color='blue')
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs Predicted Values")
plt.show()

# Conclusion
print("\n--- Conclusion ---")
print("1. The R-squared value indicates the proportion of variance in the dependent variable explained by the independent variables.")
print("2. Statistically significant variables can be identified by checking the p-values in the regression summary.")
print("3. The MSE value quantifies the average squared difference between predicted and actual values.")
print("4. Further analysis may involve handling outliers or testing non-linear models.")
